#!/usr/bin/env python3
import os, json, subprocess, sys
BASE=os.path.abspath(".")
cfg_file=os.path.join(BASE,"config","features.json")
cfg={}
if os.path.exists(cfg_file):
    cfg=json.load(open(cfg_file))
if cfg.get("enable_license_system"):
    chk=os.path.join(BASE,"optional_features","license_checker.py")
    if os.path.exists(chk):
        r=subprocess.call([sys.executable, chk])
        if r!=0:
            print("License invalid. Exiting."); sys.exit(1)
if cfg.get("enable_plugins"):
    pl=os.path.join(BASE,"plugin_loader.py")
    if os.path.exists(pl):
        subprocess.call([sys.executable, pl])
if cfg.get("enable_web_dashboard"):
    dash=os.path.join(BASE,"web","dashboard_app.py")
    if os.path.exists(dash):
        subprocess.Popen([sys.executable, dash])
core=os.path.join(BASE,"model_manager.py")
if os.path.exists(core):
    subprocess.call([sys.executable, core, "list"])
else:
    print("Core not found.")
