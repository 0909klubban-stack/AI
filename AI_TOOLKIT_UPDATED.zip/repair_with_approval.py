#!/usr/bin/env python3
# repair_with_approval.py - suggests fixes and asks for approval before making changes
import os, sys, subprocess
from pathlib import Path
from datetime import datetime

ROOT=Path(".").resolve()
LOG=ROOT/"repair_log.txt"

def log(msg):
    with LOG.open("a", encoding="utf-8") as f:
        f.write(f"[{datetime.now().isoformat()}] {msg}\n")

def ask(q):
    while True:
        a=input(q+" (y/n): ").lower()
        if a in ("y","n"): return a=="y"

def ensure_venv():
    if not (ROOT/"venv").exists():
        print("venv not found.")
        if ask("Create venv now?"):
            subprocess.check_call([sys.executable,"-m","venv","venv"])
            log("venv created")
            print("venv created")
        else:
            log("user declined venv creation")

def install_reqs():
    req=ROOT/"requirements.txt"
    if not req.exists():
        print("requirements.txt missing; skipping")
        return
    pip = "venv\\Scripts\\pip" if os.name=="nt" else "venv/bin/pip"
    print("Ready to install requirements from requirements.txt")
    if ask("Install now?"):
        subprocess.check_call([pip,"install","-r",str(req)])
        log("requirements installed")
        print("requirements installed")
    else:
        log("user declined install")

def create_safe_config():
    cfg=ROOT/"config"/"features.json"
    if not cfg.exists():
        print("Safe config missing.")
        if ask("Create safe default config?"):
            cfg.parent.mkdir(parents=True,exist_ok=True)
            cfg.write_text('''{
  "enable_gpu_check": false,
  "enable_auto_update": false,
  "enable_model_downloader": false,
  "enable_telemetry": false,
  "enable_cloud_bridge": false,
  "enable_plugins": false,
  "enable_license_system": false,
  "enable_web_dashboard": false,
  "enable_system_monitor": false
}''', encoding='utf-8')
            log("safe config created")
            print("safe config created")
        else:
            log("user declined create safe config")

def main():
    print("AI_TOOLKIT - Repair with approval")
    ensure_venv()
    install_reqs()
    create_safe_config()
    print("Done. See repair_log.txt for actions taken.")
if __name__=='__main__':
    main()
