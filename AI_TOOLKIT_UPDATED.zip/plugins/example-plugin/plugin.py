print("Example plugin executed (safe).")
