#!/usr/bin/env python3
import os, sys, subprocess
from pathlib import Path

ROOT = Path(".").resolve()
REQ = ROOT / "requirements.txt"

def check_python():
    if sys.version_info < (3,9):
        print("Python 3.9+ is required. Current:", sys.version.split()[0])
        return False
    return True

def create_venv():
    if (ROOT/"venv").exists():
        print("venv already exists.")
        return True
    print("Creating virtual environment...")
    subprocess.check_call([sys.executable, "-m", "venv", "venv"])
    print("venv created.")
    return True

def install_requirements():
    pip = "venv\\Scripts\\pip" if os.name == "nt" else "venv/bin/pip"
    if not Path(pip).exists():
        print("pip not found in venv. Activate venv or ensure creation succeeded.")
        return False
    if REQ.exists():
        print("Installing requirements...")
        subprocess.check_call([pip, "install", "--upgrade", "pip"])
        subprocess.check_call([pip, "install", "-r", str(REQ)])
        print("Dependencies installed.")
    else:
        print("No requirements.txt found. Skipping dependency install.")
    return True

def main():
    print("AI_TOOLKIT - First time setup")
    if not check_python():
        sys.exit(1)
    create_venv()
    install_requirements()
    print("Setup complete. You can run 'python self_audit.py' to audit or 'python launcher.py' to start.")
    print("All tools are opt-in; review config/features.json to enable features.")

if __name__ == '__main__':
    main()
