
AI_TOOLKIT — Comprehensive Offline AI Toolkit (Safe, Opt-in)

This toolkit collects a set of useful, offline-first, opt-in AI tools and helpers.
All tools are designed to be read-only by default and NOT modify your project files
unless you explicitly approve an action. Use in a virtual environment.

Contents (high level):
- run_this_first.py         -> One-click setup helper (creates venv, installs deps)
- self_audit.py             -> Read-only project auditor (generates report)
- RUN_SELF_AUDIT.bat        -> Windows helper to run self_audit
- repair_with_approval.py   -> Interactive repair helper (asks before any change)
- model_manager.py          -> CLI model manager (list/info/remove)
- plugin_loader.py          -> Safe plugin discovery & sandbox runner
- optional_features/license_generator.py  -> Offline license key generator
- optional_features/license_checker.py    -> License verifier (used if enabled)
- web/dashboard_app.py      -> Local Flask dashboard (opt-in)
- launcher.py               -> CLI launcher respecting config
- launcher_gui.py           -> Simple Tkinter GUI to toggle features and launch
- portable_mode.py          -> Portable-run helper (creates venv in-place)
- scripts/build_all.bat     -> PyInstaller build script for multiple entrypoints
- tools/security_toolkit.bat-> Security toolkit menu (read-only controls)
- requirements.txt          -> Base requirements (flask, psutil)
- config/features.json      -> Safe-default config (all false)
- LICENSE.txt               -> Liability disclaimer (user-responsibility)
- CONTRIBUTORS.md

Usage notes:
- Inspect scripts before running. They are intentionally explicit and interactive.
- Default config keeps everything disabled; enable features in config/features.json
- Run `python run_this_first.py` first to create venv and install dependencies.
- Run `python self_audit.py` to audit the project (report: self_audit_report.txt).


---
QUICKSTART
----------

1) Run the one-time setup (creates venv and installs dependencies):
   - Windows (double-click): `ONE_CLICK_SETUP.bat`
   - Or from terminal:
     ```
     python run_this_first.py
     python repair_with_approval.py
     ```

2) Run the read-only auditor:
   ```
   python self_audit.py
   ```

3) Start the application (safe defaults):
   ```
   python launcher.py
   ```
   Or use GUI:
   ```
   python launcher_gui.py
   ```

BUILDING EXE (Notes)
--------------------
This toolkit includes `scripts/build_all.bat` which contains example PyInstaller commands.
**Important:** Building Windows executables with PyInstaller is best performed on a Windows machine.
This environment does not build signed installer binaries for you.

If you want to build locally on Windows:
- Install Python and run the setup above
- Activate venv: `venv\Scripts\activate`
- Run: `scripts\build_all.bat`

Security & Approvals
--------------------
- The ONE_CLICK_SETUP and repair tools will **ask for confirmation** before making any changes.
- Nothing is modified without your explicit approval.
- Always review `repair_log.txt` and `self_audit_report.txt` after running tools.

