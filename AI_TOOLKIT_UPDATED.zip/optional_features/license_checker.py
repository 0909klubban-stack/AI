#!/usr/bin/env python3
# license_checker.py - verify offline license
import json,hashlib,sys
KEYFILE="license.key"
def check():
    try:
        data=json.loads(open(KEYFILE).read())
        return hashlib.sha256((data['token']+data['owner']).encode()).hexdigest()==data.get('sig')
    except Exception:
        return False
if __name__=='__main__':
    ok=check(); print("License valid?", ok); sys.exit(0 if ok else 1)
