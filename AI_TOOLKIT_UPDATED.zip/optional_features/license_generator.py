#!/usr/bin/env python3
# license_generator.py - simple offline key generator
import uuid, json, hashlib, time, sys
KEYFILE="license.key"
def generate(owner="user"):
    token=str(uuid.uuid4())
    sig=hashlib.sha256((token+owner).encode()).hexdigest()
    data={"token":token,"owner":owner,"sig":sig,"ts":int(time.time())}
    open(KEYFILE,"w").write(json.dumps(data))
    print("License created in", KEYFILE)
if __name__=='__main__':
    owner=sys.argv[1] if len(sys.argv)>1 else "user"
    generate(owner)
