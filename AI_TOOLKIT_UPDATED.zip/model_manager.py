#!/usr/bin/env python3
# Simple model manager: list, info, remove
import sys, hashlib
from pathlib import Path

MODELS=Path("models")
MODELS.mkdir(exist_ok=True)

def sha(p):
    try:
        b=p.read_bytes(); import hashlib; return hashlib.sha256(b).hexdigest()
    except: return None

def list_models():
    for p in MODELS.iterdir():
        if p.is_file():
            print(p.name, p.stat().st_size, "bytes", "sha256:"+ (sha(p) or "None"))

def info(name):
    p=MODELS/ name
    if p.exists():
        print("Path:", p.resolve())
        print("Size:", p.stat().st_size)
        print("sha256:", sha(p))
    else:
        print("Not found:", name)

def remove(name):
    p=MODELS/name
    if p.exists():
        p.unlink(); print("Removed", name)
    else:
        print("Not found", name)

if __name__=='__main__':
    if len(sys.argv)<2:
        print("Usage: model_manager.py list|info|remove <name>")
    else:
        cmd=sys.argv[1]
        if cmd=="list": list_models()
        elif cmd=="info" and len(sys.argv)>2: info(sys.argv[2])
        elif cmd=="remove" and len(sys.argv)>2: remove(sys.argv[2])
        else: print("Invalid args")
