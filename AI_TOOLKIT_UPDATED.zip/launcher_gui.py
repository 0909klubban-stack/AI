#!/usr/bin/env python3
import tkinter as tk, json, os, subprocess
BASE=os.path.abspath(".")
CFG=os.path.join(BASE,"config","features.json")
with open(CFG,"r") as f: cfg=json.load(f)
def save_and_launch():
    with open(CFG,"w") as f: json.dump(cfg,f,indent=2)
    subprocess.Popen([sys.executable, os.path.join(BASE,"launcher.py")])
    root.destroy()
def toggle(k):
    cfg[k]=not cfg.get(k, False); update_labels()
def update_labels():
    for k,btn in buttons.items(): btn.config(text=f"{k}: {'ON' if cfg.get(k) else 'OFF'}")
root=tk.Tk(); root.title("AI_TOOLKIT Launcher")
buttons={}
keys=list(cfg.keys())
for k in keys:
    f=tk.Frame(root); f.pack(fill='x')
    btn=tk.Button(f, text=k, width=40, command=lambda kk=k: toggle(kk)); btn.pack(side='left')
    buttons[k]=btn
tk.Button(root, text="Save & Launch", command=save_and_launch).pack(fill='x')
update_labels(); root.mainloop()
