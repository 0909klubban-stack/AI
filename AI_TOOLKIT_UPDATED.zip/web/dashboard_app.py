from flask import Flask, jsonify
import os, json
app=Flask(__name__)
BASE=os.path.abspath(os.path.join(os.path.dirname(__file__),".."))
def load_cfg():
    p=os.path.join(BASE,"config","features.json")
    if os.path.exists(p):
        return json.load(open(p))
    return {}
@app.route("/")
def index():
    cfg=load_cfg()
    return "<h1>AI_TOOLKIT Dashboard</h1><p>Safe default: features are off</p>"
@app.route("/models")
def models():
    md=os.path.join(BASE,"models")
    files=[]
    if os.path.exists(md):
        for f in os.listdir(md):
            files.append(f)
    return jsonify(files)
if __name__=="__main__":
    app.run(host="127.0.0.1", port=8080)
