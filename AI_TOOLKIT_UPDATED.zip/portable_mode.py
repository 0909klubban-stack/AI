#!/usr/bin/env python3
import os, subprocess, sys
VENV_DIR=os.path.join(os.getcwd(),"portable_venv")
if not os.path.exists(VENV_DIR):
    print("Creating portable venv...")
    subprocess.check_call([sys.executable, "-m", "venv", VENV_DIR])
if os.name=="nt":
    py=os.path.join(VENV_DIR,"Scripts","python.exe")
else:
    py=os.path.join(VENV_DIR,"bin","python")
print("Using python at", py)
subprocess.call([py, "launcher.py"])
