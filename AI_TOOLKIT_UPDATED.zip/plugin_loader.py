#!/usr/bin/env python3
# Safe plugin loader - runs plugin.py in subproc if 'safe' in plugin.json
import json, subprocess, sys
from pathlib import Path

PLUGINS=Path("plugins")
if not PLUGINS.exists(): PLUGINS.mkdir()

def discover():
    for d in PLUGINS.iterdir():
        if d.is_dir():
            mf=d/"plugin.json"
            if mf.exists():
                try:
                    meta=json.loads(mf.read_text(encoding='utf-8'))
                    yield d, meta
                except:
                    continue

def run_safe(d, meta):
    entry=d/(meta.get("entry","plugin.py"))
    if entry.exists():
        subprocess.run([sys.executable, str(entry)])

if __name__=='__main__':
    for d, meta in discover():
        print("Found plugin:", meta.get("name"))
        if meta.get("safe", False):
            print(" -> running in subprocess")
            run_safe(d, meta)
        else:
            print(" -> marked unsafe; skip")
