#!/usr/bin/env python3
# self_audit.py - read-only project auditor
import os, sys, ast, hashlib, subprocess, json
from pathlib import Path
from datetime import datetime

ROOT = Path(".").resolve()
REPORT = ROOT / "self_audit_report.txt"

def now(): return datetime.utcnow().isoformat()+"Z"

def list_py():
    out=[]
    for p in ROOT.rglob("*.py"):
        if any(x in p.parts for x in ("venv",".venv","env",".env","dist","build")): continue
        out.append(p)
    return sorted(out)

def compile_check(p):
    try:
        s=p.read_text(encoding='utf-8')
    except Exception as e:
        return False,str(e)
    try:
        ast.parse(s)
        compile(s,str(p),'exec')
        return True,None
    except SyntaxError as se:
        return False,f"SyntaxError: {se.msg} (line {se.lineno})"
    except Exception as e:
        return False,str(e)

def sha(p):
    h=hashlib.sha256()
    try:
        with p.open('rb') as f:
            for chunk in iter(lambda: f.read(8192), b''): h.update(chunk)
        return h.hexdigest()
    except:
        return None

def main():
    report=[]
    report.append("AI_TOOLKIT - SELF AUDIT")
    report.append("Generated: "+now())
    report.append("Project root: "+str(ROOT))
    pyfiles=list_py()
    report.append(f"Found {len(pyfiles)} python files")
    syntax=[]
    for p in pyfiles:
        ok,msg=compile_check(p)
        if not ok:
            syntax.append((p.relative_to(ROOT).as_posix(),msg))
    report.append(f"Syntax issues: {len(syntax)}")
    for s in syntax:
        report.append(f"- {s[0]} : {s[1]}")
    imports=set()
    for p in pyfiles:
        try:
            s=p.read_text(encoding='utf-8')
            tree=ast.parse(s)
            for n in ast.walk(tree):
                if isinstance(n,ast.Import):
                    for nm in n.names: imports.add(nm.name.split('.')[0])
                elif isinstance(n,ast.ImportFrom) and n.module: imports.add(n.module.split('.')[0])
        except: pass
    report.append("Distinct imports (heuristic): "+(", ".join(sorted(imports)) if imports else "(none)"))
    report.append("File hashes (sha256):")
    for p in pyfiles:
        report.append(f"- {p.relative_to(ROOT).as_posix()} : {sha(p)}")
    REPORT.write_text("\n".join(report), encoding='utf-8')
    print("Audit complete. Report written to", REPORT)

if __name__ == '__main__':
    main()
