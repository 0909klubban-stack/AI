
import json, os, sys, subprocess
BASE = os.path.abspath(os.path.dirname(__file__))
cfg_path = os.path.join(BASE, 'config', 'features.json')
cfg = {}
if os.path.exists(cfg_path):
    with open(cfg_path) as f:
        cfg = json.load(f)

# License check if enabled
if cfg.get('enable_license_system'):
    checker = os.path.join(BASE, 'optional_features', 'license_checker.py')
    if os.path.exists(checker):
        r = subprocess.call([sys.executable, checker])
        if r != 0:
            print("License invalid. Exiting.")
            sys.exit(1)

# Plugin loader
if cfg.get('enable_plugins'):
    pl = os.path.join(BASE, 'plugins', 'plugin_loader.py')
    if os.path.exists(pl):
        subprocess.call([sys.executable, pl])

# Optionally start web dashboard
if cfg.get('enable_web_dashboard'):
    dash = os.path.join(BASE, 'web', 'dashboard_app.py')
    if os.path.exists(dash):
        # start as background process
        if os.name == 'nt':
            subprocess.Popen([sys.executable, dash], creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
            subprocess.Popen([sys.executable, dash])

# Start core app
core = os.path.join(BASE, 'app', 'train_lora.py')
if os.path.exists(core):
    subprocess.call([sys.executable, core])
else:
    print("Core app not found.")
