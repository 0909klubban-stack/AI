#!/usr/bin/env python3
    # train_lora.py
    # Enkelt exempel för LoRA-finetuning med Hugging Face Transformers + PEFT + Accelerate.
    # OBS: Du måste ha modelldata lokalt i modellen-mappen (inte hämtat av skriptet).
    import os, argparse, json
    from pathlib import Path

    def main():
        parser = argparse.ArgumentParser()
        parser.add_argument("--model-dir", required=True, help="Sökväg till din base-modell (lokal)")
        parser.add_argument("--train-file", default="train_data.jsonl", help="JSONL med prompt/completion")
        parser.add_argument("--output-dir", default="output/lora", help="Var LoRA-vikter sparas")
        parser.add_argument("--epochs", type=int, default=1)
        args = parser.parse_args()

        # Vi använder ett enkelt kommando som anropar Hugging Face's 'transformers' träningsloop via 'accelerate'.
        # För enkelhetens skull skriver vi ut ett exempelkommando användaren kan köra manuellt i aktiv venv.
        cmd = f"accelerate launch --num_processes=1 --num_machines=1 train_clm.py --model_name_or_path {args.model_dir} --train_file {args.train_file} --do_train --output_dir {args.output_dir} --per_device_train_batch_size 1 --num_train_epochs {args.epochs} --bf16 False --fp16 False --learning_rate 1e-4"
        print("Följande kommando är ett exempel på hur du startar finetuning (kör i venv):")
        print(cmd)
        print("\nNotera: detta skript ägnar sig åt att göra processen tydlig. För faktisk träning, följ 'train_clm.py' i Transformers exempel eller använd scripts i text-generation-webui/ eller Hugging Face examples.")

    if __name__ == "__main__":
        main()