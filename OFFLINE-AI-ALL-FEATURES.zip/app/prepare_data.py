#!/usr/bin/env python3
    # prepare_data.py
    # Samlar kodfiler från ./data och gör enkla tränings-exempel i JSONL för LoRA finetuning.
    import os, json, argparse, pathlib

    def read_code_file(path):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()
        except Exception as e:
            print("Misslyckades läsa:", path, e)
            return ""

    def make_prompt_from_code(code, filename):
        # Enkel format: använd filens innehåll som 'input' och be modellen att fortsätta eller förklara.
        prompt = f"Följande fil: {filename}\n\nKOD BEGIN\n{code}\nKOD END\n\nUppgift: Förklara vad denna kod gör och skriv ett exempel på hur den används."
        completion = "ANVÄND DEN OVAN FÖR ATT GENERERA FORTSÄTTNING ELLER FÖRKLARING."
        return {"prompt": prompt, "completion": completion}

    def main():
        parser = argparse.ArgumentParser()
        parser.add_argument("--data-dir", default="data", help="Mapp med kodfiler (py, js, html...)")
        parser.add_argument("--out", default="train_data.jsonl", help="Utfil JSONL")
        args = parser.parse_args()
        p = pathlib.Path(args.data_dir)
        files = list(p.rglob("*.*"))
        with open(args.out, "w", encoding="utf-8") as out:
            for f in files:
                if f.is_file():
                    code = read_code_file(f)
                    if len(code.strip()) < 20:
                        continue
                    item = make_prompt_from_code(code, str(f))
                    out.write(json.dumps(item, ensure_ascii=False) + "\n")
        print("Skapade träningsdata i", args.out)

    if __name__ == "__main__":
        main()