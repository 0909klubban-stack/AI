
# OFFLINE-AI – Production Build

This package contains a cleaned, runnable production structure.

## Structure
- app/        -> Core Python logic
- models/     -> Local AI models
- webui/      -> Optional UI assets
- scripts/    -> Build & installer scripts

## Install (Windows)
Run:
scripts\install.bat

## Build EXE
scripts\build_exe.bat

## Run
venv\Scripts\activate
python app\train_lora.py


---

## Optional Feature System

All extra features are located in:
optional_features/

You enable or disable everything using:
config/features.json

Example:
enable_gpu_check: true/false
enable_auto_update: true/false
enable_model_downloader: true/false
enable_telemetry: true/false
enable_cloud_bridge: true/false

### Launch Methods
CLI:
python launcher.py

GUI:
python launcher_gui.py


---

## SAFE DEFAULT MODE (Important)

All advanced systems are DISABLED by default.
To enable anything:
edit -> config/features.json

This guarantees:
✔ Offline safety
✔ No telemetry
✔ No background services
✔ No auto updates
✔ No cloud usage

User is always in full control.


# ALL FEATURES INSTALLED (OPT-IN)

This package contains a full feature set; all features are OFF by default in config/features.json.

To enable features, edit config/features.json or use the GUI launcher.

Start the web dashboard locally (if enabled): python -m web.dashboard_app

Model manager CLI: python scripts/model_manager.py list

Plugin manager: python plugins/plugin_manager.py install <zip>

License generator: python optional_features/license_generator.py
License check: python optional_features/license_checker.py

Build all executables: scripts\build_all.bat
Portable mode: scripts\portable_mode.py
