
key = input("Enter license key: ")
if key:
    print("License accepted (stub).")
