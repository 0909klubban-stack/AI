
import json, hashlib, sys
KEYSTORE = 'license.key'
def check():
    try:
        with open(KEYSTORE) as f:
            data = json.load(f)
        expected = hashlib.sha256((data['token']+data['owner']).encode()).hexdigest()
        return expected == data.get('sig')
    except Exception:
        return False

if __name__ == '__main__':
    ok = check()
    print("License valid?" , ok)
    sys.exit(0 if ok else 1)
