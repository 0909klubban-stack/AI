
import uuid, hashlib, json, time
KEYSTORE = 'license.key'

def generate(owner='user'):
    token = str(uuid.uuid4())
    sig = hashlib.sha256((token+owner).encode()).hexdigest()
    data = {'token': token, 'owner': owner, 'sig': sig, 'ts': int(time.time())}
    with open(KEYSTORE,'w') as f:
        json.dump(data,f)
    print("License generated and saved to", KEYSTORE)
    print("Key token:", token)

if __name__ == '__main__':
    generate()
