
from http.server import SimpleHTTPRequestHandler, HTTPServer

print("Optional Web Dashboard running at http://localhost:8080")
server = HTTPServer(("localhost", 8080), SimpleHTTPRequestHandler)
server.serve_forever()
