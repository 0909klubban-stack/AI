
import psutil, time, logging, os
logging.basicConfig(filename='system_monitor.log', level=logging.INFO, format='%(asctime)s %(message)s')
while True:
    cpu = psutil.cpu_percent()
    ram = psutil.virtual_memory().percent
    logging.info(f"CPU:{cpu} RAM:{ram}")
    time.sleep(2)
