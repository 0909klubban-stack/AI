
import os, hashlib, json
from pathlib import Path

MODELS = Path('models')
MODELS.mkdir(exist_ok=True)

def list_models():
    for p in MODELS.iterdir():
        if p.is_file():
            h = hashlib.sha256(p.read_bytes()).hexdigest()[:8]
            print(f"{p.name} — {p.stat().st_size} bytes — sha256:{h}")

def remove(name):
    p = MODELS / name
    if p.exists():
        p.unlink()
        print("Removed", name)
    else:
        print("Not found")

def info(name):
    p = MODELS / name
    if p.exists():
        print("Path:", p.resolve())
        print("Size:", p.stat().st_size)
        print("sha256:", hashlib.sha256(p.read_bytes()).hexdigest())
    else:
        print("Not found")

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print("Usage: model_manager.py list|remove|info <name>")
    elif sys.argv[1] == 'list':
        list_models()
    elif sys.argv[1] == 'remove':
        remove(sys.argv[2])
    elif sys.argv[1] == 'info':
        info(sys.argv[2])
