
import os, subprocess, sys
# Portable mode: create venv inside portable_media if missing and run launcher
VENV_DIR = os.path.join(os.getcwd(),'portable_venv')
if not os.path.exists(VENV_DIR):
    subprocess.check_call([sys.executable, '-m', 'venv', VENV_DIR])
if os.name == 'nt':
    ACT = os.path.join(VENV_DIR,'Scripts','activate.bat')
    run = os.path.join(VENV_DIR,'Scripts','python.exe')
else:
    ACT = os.path.join(VENV_DIR,'bin','activate')
    run = os.path.join(VENV_DIR,'bin','python')
print("Using portable python at", run)
# Run launcher
launcher = os.path.join(os.getcwd(),'launcher.py')
subprocess.Popen([run, launcher])
