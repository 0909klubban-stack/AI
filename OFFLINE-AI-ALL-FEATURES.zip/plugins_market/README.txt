
# Local plugin marketplace (skeleton)
# Place zip files into plugins_market/ to install via plugin_manager
