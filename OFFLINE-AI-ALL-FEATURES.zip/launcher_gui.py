
import tkinter as tk, json, os, subprocess
BASE = os.path.abspath(os.path.dirname(__file__))
CFG = os.path.join(BASE, 'config', 'features.json')
with open(CFG,'r') as f:
    cfg = json.load(f)

def save_and_launch():
    with open(CFG,'w') as f:
        json.dump(cfg, f, indent=2)
    subprocess.Popen([sys.executable, os.path.join(BASE,'launcher.py')])
    root.destroy()

def toggle(k):
    cfg[k] = not cfg.get(k, False)
    update_labels()

def update_labels():
    for k,v in vars.items():
        btn = vars[k]
        btn.config(text=f"{k}: {'ON' if cfg.get(k) else 'OFF'}")

root = tk.Tk()
root.title("OFFLINE-AI Configuration Launcher")

vars = {}
keys = ['enable_gpu_check','enable_auto_update','enable_model_downloader','enable_telemetry','enable_cloud_bridge','enable_plugins','enable_license_system','enable_web_dashboard','enable_system_monitor']
for k in keys:
    frame = tk.Frame(root)
    frame.pack(fill='x')
    btn = tk.Button(frame, text=k, width=30, command=lambda kk=k: toggle(kk))
    btn.pack(side='left')
    vars[k]=btn

launch_btn = tk.Button(root, text="Save & Launch", command=save_and_launch)
launch_btn.pack(fill='x')
update_labels()
root.mainloop()
