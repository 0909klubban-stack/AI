
import os, json, subprocess, sys
from pathlib import Path

PLUGINS = Path('plugins')
def discover():
    for d in PLUGINS.iterdir():
        if d.is_dir():
            mf = d / 'plugin.json'
            if mf.exists():
                try:
                    with open(mf) as f:
                        meta = json.load(f)
                    yield d, meta
                except Exception:
                    continue

def run_safe(plugin_dir, meta):
    entry = plugin_dir / meta.get('entry','plugin.py')
    if entry.exists():
        # Run in subprocess to avoid importing into main interpreter
        subprocess.run([sys.executable, str(entry)], check=False)

if __name__ == '__main__':
    for d, meta in discover():
        print("Found plugin:", meta.get('name'))
        if meta.get('safe', False):
            run_safe(d, meta)
        else:
            print("Plugin marked unsafe; skip by default.")
