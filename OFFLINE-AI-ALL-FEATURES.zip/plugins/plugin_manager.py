
import zipfile, os, shutil
from pathlib import Path

MARKET = Path('plugins_market')
PLUGINS = Path('plugins')

def install(zip_path):
    with zipfile.ZipFile(zip_path,'r') as z:
        name = Path(zip_path).stem
        target = PLUGINS / name
        if target.exists():
            shutil.rmtree(target)
        z.extractall(target)
        print("Installed", name)

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print("Usage: plugin_manager.py install <zip>")
    else:
        install(sys.argv[1])
