print("Example plugin executed (sandboxed).")
