
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, jsonify
import os, json, subprocess, hashlib, time

app = Flask(__name__, template_folder='templates', static_folder='static')
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

def load_config():
    p = os.path.join(BASE_DIR, 'config', 'features.json')
    if os.path.exists(p):
        with open(p,'r') as f:
            return json.load(f)
    return {}

@app.route('/')
def index():
    cfg = load_config()
    return render_template('index.html', config=cfg)

@app.route('/models')
def models():
    models_dir = os.path.join(BASE_DIR, 'models')
    files = []
    if os.path.exists(models_dir):
        for fn in os.listdir(models_dir):
            files.append({'name': fn, 'size': os.path.getsize(os.path.join(models_dir,fn))})
    return render_template('models.html', models=files)

@app.route('/models/upload', methods=['POST'])
def upload_model():
    f = request.files.get('file')
    if not f:
        return redirect(url_for('models'))
    models_dir = os.path.join(BASE_DIR, 'models')
    os.makedirs(models_dir, exist_ok=True)
    dest = os.path.join(models_dir, f.filename)
    f.save(dest)
    return redirect(url_for('models'))

@app.route('/monitor')
def monitor():
    # simple snapshot
    try:
        import psutil
        stats = {'cpu': psutil.cpu_percent(), 'ram': psutil.virtual_memory().percent}
    except Exception:
        stats = {'cpu': None, 'ram': None}
    return jsonify(stats)

@app.route('/launch')
def launch():
    # start core via launcher (non-blocking)
    launcher = os.path.join(BASE_DIR, 'launcher.py')
    if os.path.exists(launcher):
        # Start in background
        if os.name == 'nt':
            subprocess.Popen(['python', launcher], creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
            subprocess.Popen(['python3', launcher])
        return "Launched", 200
    return "Launcher not found", 404

if __name__ == '__main__':
    # default safe mode only on localhost
    app.run(host='127.0.0.1', port=8080, debug=False)
