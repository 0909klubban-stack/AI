#!/usr/bin/env python3
    # safe_wrapper.py
    # Läser MIN_AI_SAKERHET.yaml och blockerar förbjudna instruktioner.
    import yaml, argparse, sys, re
    from pathlib import Path

    DEFAULT_SAFETY_FILE = "MIN_AI_SAKERHET.yaml"
    FORBIDDEN_KEYWORDS = [
        "hack", "ddos", "malware", "virus", "exploit", "sårbar", "sårbarhet", "intrång", "crack", "trojan", "rootkit"
    ]

    def load_rules(p):
        p = Path(p)
        if not p.exists():
            print("Säkerhetsfil saknas:", p, file=sys.stderr)
            return {}
        with p.open(encoding="utf-8") as f:
            return yaml.safe_load(f) or {}

    def check_prompt(prompt, rules):
        lower = prompt.lower()
        for kw in FORBIDDEN_KEYWORDS:
            if kw in lower:
                return False, f"BLOCKED: Innehåller förbjudet ord: {kw}"
        sek = rules.get("säkerhet", {})
        if sek.get("skadlig_kod", "nej") != "nej":
            return False, "BLOCKED: skadlig_kod-regel blockerar alla förfrågningar."
        if sek.get("hacking_kod", "nej") != "nej":
            return False, "BLOCKED: hacking_kod-regel blockerar alla förfrågningar."
        # Enkel regex-kontroll för kommandon som kan vara farliga i vissa kontext
        dangerous_cmds = [r'\brm\s+-rf\b', r'\bwget\b', r'\bcurl\b', r'\bssh\b']
        for pat in dangerous_cmds:
            if re.search(pat, prompt, flags=re.IGNORECASE):
                return False, "BLOCKED: Möjligt farligt kommando upptäckt."
        return True, "OK"

    def main():
        parser = argparse.ArgumentParser(description="Safe wrapper för prompts")
        parser.add_argument("--safety", default=DEFAULT_SAFETY_FILE)
        parser.add_argument("--prompt", type=str, help="Prompt som sträng (annars läs stdin)")
        parser.add_argument("--call-local-api", action="store_true", help="Försök POST till local webui API (om implementerat)")
        args = parser.parse_args()
        rules = load_rules(args.safety)
        if args.prompt:
            prompt = args.prompt
        else:
            prompt = sys.stdin.read()
        ok, msg = check_prompt(prompt, rules)
        if not ok:
            print(msg)
            sys.exit(2)
        print("Prompt OK. Här är prompten som kan skickas vidare:")
        print(prompt)
        # Om användaren vill, kan detta script utökas för att POSTa prompten till en local webui API (t.ex. text-generation-webui REST API).

    if __name__ == '__main__':
        main()