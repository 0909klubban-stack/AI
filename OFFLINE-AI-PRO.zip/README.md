
# OFFLINE-AI – Production Build

This package contains a cleaned, runnable production structure.

## Structure
- app/        -> Core Python logic
- models/     -> Local AI models
- webui/      -> Optional UI assets
- scripts/    -> Build & installer scripts

## Install (Windows)
Run:
scripts\install.bat

## Build EXE
scripts\build_exe.bat

## Run
venv\Scripts\activate
python app\train_lora.py
